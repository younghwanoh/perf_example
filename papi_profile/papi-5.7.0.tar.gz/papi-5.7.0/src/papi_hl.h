#ifndef PAPI_HL_H
#define PAPI_HL_H

void _papi_hwi_shutdown_highlevel(  );

#endif
